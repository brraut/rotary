<?php 

namespace App\Repositories\Contributor;

use App\Model\Contributor;

class ContributorRepository implements ContributorInterface
{
    public function __construct(Contributor $contributor)
    {
    		$this->contributor = $contributor;
    } 

    public function all()
    {
    		return $this->contributor->all();
    } 

    public function save($array)
    {
    		$this->contributor->create($array);
    } 

    public function findById($id)
    {
    		return $this->contributor->find($id);
    } 

    public function renew($id, $array)
    {
            $this->findById($id)->update($array);
    } 

    public function remove($id)
    {
    		$this->findById($id)->delete();
    } 
}